# Package writing July 20

#############################################
################# Functions #################
#############################################
clean.seg.func = function(TextT, TextF){
  # clean.seg.func: Clean emoji from raw weibo and segment sentence into seperate words, build dictionary.
  # input: TextT-True input, TextF-False input
  # involving package: jiebaR
  # involving function: gsub-words regularization and excluding "http://" link
  # return: dictionary based on input, cleaned inputs
  require(jiebaR)
  cutter = worker()
  
  # Clean Emoji-True
  Emoji.free.T <- sapply(TextT, function(row) iconv(row, "UTF-8", "CN-GB", sub="") )
  Emoji.free.T <- as.vector( sapply(Emoji.free.T, function(row) iconv(row, "CN-GB", "UTF-8", sub="") ) )
  # Clean Hashtag
  Hash.free.T <- as.vector( sapply(Emoji.free.T, function(row) gsub('\\#', '\\1 \\2', row)) )
  # Clean Link
  Link.free.T <- as.vector( sapply(Hash.free.T, function(row) gsub('\\S+ttp://\\S+', '', row) ) )
  # Segment all sentence
  seg.text.T <- unlist(lapply(Link.free.T, function(row) segment( row, cutter)))
  # For-Training-False
  Emoji.free.F <- sapply(TextF, function(row) iconv(row, "UTF-8", "CN-GB", sub="") )
  Emoji.free.F <- as.vector( sapply(Emoji.free.F, function(row) iconv(row, "CN-GB", "UTF-8", sub="") ) )
  Hash.free.F <- as.vector( sapply(Emoji.free.F, function(row) gsub('\\#', '\\1 \\2', row)) )
  Link.free.F <- as.vector( sapply(Hash.free.F, function(row) gsub('\\S+ttp://\\S+', '', row) ) )
  seg.text.F <- unlist(lapply(Link.free.F, function(row) segment( row, cutter)))
  
  seg.text = c(seg.text.T, seg.text.F)
  freq = freq(seg.text)
  dict  = freq[which(freq$freq > 1), ]
  # words with frequency more than 1
  dict2 = dict[which(nchar(dict[,1]) > 1), ]  
  # words with frequency more than 1 and character length more than 1
  Clean.text = c(Link.free.T, Link.free.F)
  TF.ID = rep(1:0, c(length(Link.free.T), length(Link.free.F)))
  
  return( list( dict2 = dict2,
                vec = Clean.text,
                vecID = TF.ID ) )
}

input.est.func = function(textdict){
  # input.est.func: Transform weibo sentence into 0/1 vector according to the dictionary
  # input: textdict-list of dictionary and words vector
  # involving package: jiebaR
  # involving function: Matrix(, sparse = T)
  # return: Y-X format matrix based on textdict, 0/1 according to words appearance based on dictionary
  require(Matrix)
  require(SparseM)
  require(jiebaR)
  cutter = worker()
  
  xdata = NULL
  # xdata <- matrix(0, length(textdict$vec), dim(textdict$dict2)[1])
  # for( i in 1:length(textdict$vec) ){
  #   sdata = segment( textdict$vec[i] , cutter )
  #   fdata = freq(sdata)
  #   loc = match(fdata$char, textdict$dict2$char) # dict is the full, therefore the program is ok here
  #   xdata[i,loc] = 1
  # }
  
  seg <- lapply(textdict$vec, function(row) segment( row, cutter))
  loc <- lapply(seg, function(row) unique(match(row, textdict$dict2$char)))
  # mloc <- lapply(loc, function(row) replace(row, is.na(row) , 0))
  xdata <- Matrix( unlist( lapply(loc, function(row) replace(rep(0, length(textdict$dict2$char)), row[!is.na(row)], 1)) ), ncol = length(textdict$dict2$char), byrow = T, sparse = T)
  YN = rep(1:0, c(length(which(textdict$vecID==1)), length(which(textdict$vecID==0))))
  yxdata = cbind( YN, xdata)
  rownames(yxdata) = rownames(yxdata, do.NULL = FALSE, prefix = "Obs.")
  colnames(yxdata) = c("Y/N", rep(1:(dim(yxdata)[2]-1)))
  
  return( list( dict2 = textdict$dict2,
                yxdata = yxdata) )
}

est.func = function(input){
  # est.func: Select parameters from dictionary
  # input: Y-X format data and dimension dictionary
  # involving package: glmnet, Smatrix
  # involving function: glmnet
  # Return is the selected features from model
  require(glmnet)
  
  glmmod = glmnet(input$yxdata[,-1], input$yxdata[,1], alpha=1, family="binomial")
  
  tLL <- glmmod$nulldev - deviance(glmmod)
  k <- glmmod$df
  n <- glmmod$nobs
  AIC <- -tLL+2*k+2*k*(k+1)/(n-k-1)
  BIC <- log(n)*k - tLL
  LID1 = which(AIC==min(AIC)) 
  LID2 = which(BIC==min(BIC)) 
  
  indexA = which(round(glmmod$beta[,LID1],5)!=0)
  betaAIC = round(glmmod$beta[indexA,LID1],5)
  dictAIC = input$dict2[indexA,1]
  names(betaAIC) = dictAIC
  # betaAIC[order(betaAIC)]
  
  indexB = which(round(glmmod$beta[,LID2],5)!=0)
  betaBIC = round(glmmod$beta[indexB,LID2],5)
  dictBIC = input$dict2[indexB,1]
  names(betaBIC) = dictBIC
  # betaBIC[order(betaBIC)]
  
  return( list( glmmod = glmmod, 
                betaAIC = betaAIC,
                betaBIC = betaBIC ) )
}

predict.func = function(Datanew, threshold, betas){
  # predic.func: Make prediction based on estimation result (features and coefficients) for incoming new weibo
  # input: weibo sentence, prediction threshold (low and high), selected coefficients
  # involving package: jiebaR, Smatrix
  # involving function: gsub
  # return: effectivesize, updatesize(threshold), prediction result, uncertain observation
  require(jiebaR)
  require(Matrix)
  require(SparseM)
  cutter = worker()
  
  YN = rep(1, length(Datanew))
  dict = names(betas)
  
  Emoji.free <- sapply(Datanew, function(row) iconv(row, "UTF-8", "CN-GB", sub="") )
  Emoji.free <- as.vector( sapply(Emoji.free, function(row) iconv(row, "CN-GB", "UTF-8", sub="") ) )
  Hash.free <- as.vector( sapply(Emoji.free, function(row) gsub('\\#', '\\1 \\2', row)) )
  Link.free <- as.vector( sapply(Hash.free, function(row) gsub('\\S+ttp://\\S+', '', row) ) )
  seg.text <- lapply(Link.free, function(row) segment( row, cutter))
  loc <- lapply(seg.text, function(row) unique(match(row, dict)))
  # mloc <- lapply(loc, function(row) replace(row, is.na(row) , 0))
  xtest <- Matrix( unlist( lapply(loc, function(row) replace(rep(0, length(dict)), row[!is.na(row)], 1)) ), ncol = length(dict), byrow = T, sparse = T)
  
  ahat = as.vector( xtest %*% as.vector(betas) )
  phat = exp(ahat)/(1+exp(ahat))
  phat = round(phat,5)
  predic.prob = phat
  hist(predic.prob, 20)
  yhat = rep(0, length(phat))
  yhat[which(phat >= threshold[2])] = 1
  predT = which(yhat==1) 
  predF = which(phat < threshold[1])
  Effectivesize = length(phat[which(phat!=0.5)])
  Effectivesize = cbind(Effectivesize, Effectivesize / length(Datanew)) 
  Updatesize = length(predT) + length(predF)
  Updatesize = cbind(Updatesize, Updatesize / length(Datanew))
  
  TrainnewT = Datanew[predT]
  TrainnewF = Datanew[predF]
  Uncertain = Datanew[-c(predT, predF)]
  
  return( list( Effectivesize = Effectivesize,
                Updatesize  = Updatesize,
                Trainnew = list( TrainnewT = TrainnewT, TrainnewF = TrainnewF, predT = predT, predF = predF ),
                Uncertain = Uncertain ) )
}

beta.func = function(AllUP, retrain.size){
  # beta.func: select useful features from the input training set
  # input: weibo sentence with label
  # involving function: clean.seg.func, input.est.func, est.func
  # return: All selected features in resample process with names and coefficients
  TextTUP = AllUP[1:retrain.size[1]]
  TextFUP = AllUP[(retrain.size[1]+1):sum(retrain.size)]
  textdict = clean.seg.func(TextTUP, TextFUP)
  input = input.est.func(textdict)
  result = est.func(input)
  allbeta = NULL
  allbeta = c(allbeta, result$betaAIC)
  return(allbeta = allbeta)
}

table.func = function(TextUPT, TextUPF, resample.times, count.prop, retrain.size){
  # table.func: count the selected features across the resample process
  # input: training set, resample resample.times, frequency count.prop
  # involving functions: beta.func, apply(), tapply(), table, match
  # return: table of features fequency (negative and positive)
  require(SparseM)
  
  rs.seed = c(201708:(201707+resample.times))
  AllUPT = sapply(rs.seed, function(row) { set.seed(row) 
    TextUPT[sample(1:length(TextUPT), retrain.size[1], replace = F)]
  })
  AllUPF = sapply(rs.seed, function(row) { set.seed(row) 
    TextUPF[sample(1:length(TextUPF), retrain.size[2], replace = F)]
  })
  AllUP = t(rbind(AllUPT, AllUPF))
  # AllUP: the matrix with row be resample and column be observation
  allbetas = apply(AllUP, 1, function(x) beta.func(x,retrain.size))
  allbeta = unlist(allbetas)
  betas = tapply(allbeta, names(allbeta), sum)
  ave.betas = betas / resample.times
  
  ttt = table(names(allbeta))[which(table(names(allbeta)) >= floor(resample.times*count.prop))]
  ll = match(names(allbeta), names(ttt))
  mmm = allbeta[!is.na(ll)]
  nnn = unique(names(mmm[which(mmm < 0)]))
  ccc = rep(-1, length(ttt))
  ccc[is.na(match(names(ttt), nnn))] = 1
  rrr = ttt * ccc
  
  rs.ave.beta = round(ave.betas[ !is.na(match( names(ave.betas), names(rrr) ) ) ], 4)
  
  return( list(table.features = rrr,
               beta.features = rs.ave.beta) )
}


sta.main.func = function(Train.T, Train.F, Test.text, resample.times, retrain.size, count.prop, train.update.threshold, sec.update.threshold){
  # seed.func: start with different seeds and compare the results of table, effectivesize, updatesize
  # input: seeds, training set, resample time, frequency proportion
  # involving functions: clean/input/est.func, predit.func, table.func
  # return: effectivesize, updatesize, false percentage, table, proportion of first step features in resampling, updates in resampling, uncertain obs
  # Train.T: True train text
  # Train.F: False train text
  # Test.text: Test text
  
  print(Sys.time())
  print("Train start")
  textdict = clean.seg.func(Train.T, Train.F)
  input = input.est.func(textdict)
  result = est.func(input)
  print("Train down")
  print(Sys.time())
  print("Prediction start")
  resultp = predict.func(Test.text, train.update.threshold, result$betaAIC)
  print(paste("Prediction down,", " ","Threshold:", "(", train.update.threshold[1], ",", train.update.threshold[2], ")", sep = " "))
  print(Sys.time())
  TextUPT = as.vector(c(Train.T, resultp$Trainnew$TrainnewT))
  TextUPF = as.vector(c(Train.F, resultp$Trainnew$TrainnewF))
  print("Resample start")
  table.result = table.func(TextUPT, TextUPF, resample.times, count.prop, retrain.size)
  print("Resample down")
  print(Sys.time())
  Start.prop = sum(!is.na(match(names(result$betaAIC),names(table.result$table.features)))) / length(table.result$table.features)
  Update.prop = 1 - Start.prop
  Update.features = table.result$table.features[is.na(match(names(table.result$table.features), names(result$betaAIC)))] / resample.times
  print("Secondary Est. start")
  sec.est = predict.func(Test.text, sec.update.threshold, table.result$beta.features)
  print("Secondary Est. done")
  print(Sys.time())
  
  return( list(Effectivesize = resultp$Effectivesize,
               Second.Effectivesize = sec.est$Effectivesize,
               Updatesize = resultp$Updatesize,
               Second.Updatesize = sec.est$Updatesize,
               Table = table.result,
               Start.prop = Start.prop,
               Update.prop = Update.prop,
               Update.features = Update.features,
               Training.est = resultp,
               Second.est = sec.est) )
}
